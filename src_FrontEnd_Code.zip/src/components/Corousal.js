import React from "react";
import homeimage from "../assets/images/homeimage.jpg";

function Corousal(props) {
  return (
    <div className="carousel-inner col-lg-17">
      <div className="carousel-item active">
        <img src={homeimage} width="100%" height="380" />
      </div>
    </div>
  );
}

export default Corousal;
