import logo from "./logo.svg";
import "./App.css";
import { Route, Switch } from "react-router-dom";
import Home from "./components/Home";
import Login from "./components/Login";

function App() {
  return (
    <main>
      <switch>
        <Route path="/" component={Home} exact />
        <Route path="/login" component={Login} />
      </switch>
    </main>
  );
}

export default App;
